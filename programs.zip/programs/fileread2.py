# reading teh file line by line
# traditional way or regular way
fobj = open("./csvfiles/empinfo.csv","r") 
for line in fobj:
    print(line.strip())
fobj.close()

# context manager  # pythonic way
# using context manager file will be closed automatically
with open("./csvfiles/empinfo.csv","r") as fobj:
    for line in fobj:
        print(line.strip())

# fobj.readlines()
with open("./csvfiles/empinfo.csv","r") as fobj:
    print(fobj.readlines())  # output is the list

# fobj.read() --> returns the string
with open("./csvfiles/empinfo.csv","r") as fobj:
    print(fobj.read()) 

# using pandas
import pandas as pd
df = pd.read_csv("./csvfiles/empinfo.csv")
print(df)    

# using csv library
import csv
with open("./csvfiles/empinfo.csv","r") as fobj:
    reader = csv.reader(fobj)  #converting file object to csv object
    for line in reader:
        print(line)   # each line is one list