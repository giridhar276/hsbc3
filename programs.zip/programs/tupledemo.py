

atup = (10,20,30,40)

print(atup.count(10))