
#fobj = open(".\csvfiles\empinfo.csv","r")  # windows
fobj = open("./csvfiles/empinfo.csv","r") 

for line in fobj:
    print(line.strip())

fobj.close()