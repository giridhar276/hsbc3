alist = [45,3,2,56,32,56,32,5,16,43]
# list slicing
print(alist[::-1]) 
#adding the value
alist.append(94)
print("After appending :",alist)
alist.extend([5,56,32,64])
print("After extending :",alist)
#list.pop(index): value at that index will be removed
alist.pop(0)
print("After pop operation :",alist)
alist.remove(16) # 16 will be removed from the list
print("AFter removing :",alist)
# sorting value in ascending order
alist.sort()   # alist.sort(reverse=True)
print("After sorting :",alist)
# reversing values
alist.reverse()
print("After reversing :",alist)

alist = [10,10,10,10,20,20,30,30]
getcount = alist.count(10)
for item in range(0,getcount):
    alist.remove(10)
print(alist)


# loop
alist = [10,10,10,10,20,20,30,30]
for item in alist:
    print(item)