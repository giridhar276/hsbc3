
name = "python programming"
print(name)
print("I love",name)

#slicing
#string[start:stop:step]
print(name[0:10])
print(name[5:10])
print(name[::])
print(name[:])
print(name[0:18:2])
print(name[1:18:3])
print(name[::4])
print(name[-1])
print(name[-5:-1])
print(name[::-1])
## concatenating strings  +
aname = "python"
bname = "programming"
cname ="language"
final = aname + " " + bname + " " + cname
print(final)
# repetition operator : * 
print(aname * 5)

######################string methods ################
name = "python programming"
print(name)
print(name.capitalize())  #Python
print(name.upper())     # displaying the string in upper
print(name)
print(name.lower())
print(name.split(" "))
print(name.replace("python","ruby"))
print(name.count("p")) #2
print(name.find("ho")) #3
print(name.find("yre")) #-1  : if substring is not found it returns -1
print(name.isupper())
print(name.islower())
aname = " python "
print(len(aname)) 
print(len(aname.strip()))  # obj.strip() will remove whitespaces at both ends


# string is immutable
name = "python"
#name[0] = "j"
print(name)

# conditions
name = "python"
# simple if
if name.startswith("p"):
    print("its python")

# if-else
if name.startswith("p"):
    print("its python")
else:
    print("someother langauge")

# if-elif-elif-elif..else
if name.startswith("p"):
    print("its python")
elif name.startswith("j"):
    print("java progarmming")
elif name.startswith("r"):
    print("ruby programming")
else:
    print("someother language")


# for loop - reaching each character and displaying line by line
name = "python"
for char in name:
    print(char)


# reverse the string
name = "python"
for char in name[::-1]:
    print(char)