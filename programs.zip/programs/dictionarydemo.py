
book = {"chap1":10 ,"chap2":20 ,"chap3":30}

print(book)

# display value
print(book["chap1"]) # 10
print(book["chap2"]) # 20

# display keys
print(book.keys())
# display values
print(book.values())
# display items()
print(book.items())
# display value
#print(book["chap5"]) # If key is not existing it will display KeyError
print(book.get("chap5")) # if key is not existing return None

book.pop("chap1")   # chap1,10 will be removed from dictionary
print("After pop operation :",book)
book.popitem()      # will remove last key,value pair
print("After popitem operation :",book)
# combining both dictionaries
newbook = {"chap8":80,"chap9":90}
book.update(newbook)  # newbook will be updated to the book
# combining both dictionaries
finalbook = {**book,**newbook}
print(finalbook)


# display keys line by line
for key in book.keys():
    print(key)

# display values line by line
for value in book.values():
    print(value)

# display key and value
for key,value in book.items():
    print("key:", key)
    print("value:",value)